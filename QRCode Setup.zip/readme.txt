﻿- setup font barcode into c:\windows\fonts
- run regcom.bat (run as admin and notification success)